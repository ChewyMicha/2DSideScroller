﻿
using UnityEngine;

public class PlayerController : MonoBehaviour {

    private Transform playerTransform;
    private float playerPosX;
    private Rigidbody2D rb;

    public int speed = 100;        // x speed the player is moving at
    public int jumpScale = 10000;  // jumppower
    private bool grounded;         //checks if the player hits a ground object(tag:"grounded") so hes allowed to jump
    private bool jumped;           //message from updated to fixedUpdate that the player should jump now!
                 


    private void Awake()
    {
        playerTransform = transform;
        rb = GetComponent<Rigidbody2D>();
    }

    private void Update()
    {       // if space or left mouseButton
       if ((Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))&&(grounded))
       {
           jumped = true; // FixedUpdate missed the Input sometimes
       }
        playerTransform.position += new Vector3(speed, 0, 0) * Time.deltaTime; // makes the player move
    }

    private void FixedUpdate()
    {
      if (jumped)
      {
       // Debug.Log("jump");
        rb.AddForce(Vector3.up * jumpScale * Time.deltaTime); // makes player jump
        jumped = false;
      }
    }
    
     // this worked out for the scope of the project
     // if i gonne turn this into an acctual game i probeply need to change it 
    private void OnCollisionStay2D (Collision2D collision)
    {
        if (collision != null && collision.collider.CompareTag("Ground"))
        {
            grounded = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision != null && collision.collider.CompareTag("Ground"))
        {
            grounded = false;
        }
    }
}
