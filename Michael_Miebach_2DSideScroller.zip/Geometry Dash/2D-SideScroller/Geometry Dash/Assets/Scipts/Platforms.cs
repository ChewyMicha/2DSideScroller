﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// destorys unnecessary platforms
/// </summary>
public class Platforms : MonoBehaviour {

    private Transform player;

    private void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        
    }
    private void UpdateFixed()
    {   //clears up unnecessacry platforms
        if (player.transform.position.x - transform.position.x > 1000)
        {
            Destroy(transform.gameObject);
        }
    }
}
