﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(SpriteRenderer))]

public class Tiling : MonoBehaviour
{
    public GameObject partPrefab;//ref to the Background Prefab
    public bool rightPart = false;// true if Objects has a Part on its right
    public bool leftPart = false;// true if Objects has a Part on its left

    public bool reverse = false; // for not tilable backgrounds
                                 //do we need to flip the sprite?

    private float partWidth;// spritewidth
    private int offset = 2;// offset for the calc... prevents mistakes and makes sure the player dosent see the spawn

    private Transform myTransform;// background 
    public Camera cam;    // main Camera ref

    private void Awake()
    {
        myTransform = transform;// background 
        cam = Camera.main; // main Camera ref
    }
    private void Start()
    {
        SpriteRenderer renderer = GetComponent<SpriteRenderer>();
        partWidth = renderer.sprite.bounds.size.x;//calcs sprite Length
    }
    private void Update()
    {
        if (leftPart == false || rightPart == false)// checks if the objects needs a part to its left/right
        {
            float camViewSize = cam.orthographicSize * Screen.width / Screen.height; //calcs what the edges of the cam can see

            float camEdgeRight = (myTransform.position.x + partWidth / 2) - camViewSize; // postion where we need to spawn a new one
            float camEdgeLeft = (myTransform.position.x - partWidth / 2) + camViewSize;// postion where we need to spawn a new one

            if (cam.transform.position.x >= camEdgeRight - offset && rightPart == false) // if cam acctaully hits this postion(left)
            { 
                SpawnPart(1); // enter 1 so it spawns a part to the left
                rightPart = true;//tells the old background that it has a neighbour now 
            }
            else if (cam.transform.position.x <= camEdgeLeft + offset && leftPart == false)// if cam acctaully hits this postion(right)
            {
                SpawnPart(-1); // enter -1 so it spawns a part to the right
                 leftPart = true;//tells the old background that it has a neighbour now 
            }
        }
      
            if(Vector3.Distance(cam.transform.position, myTransform.position)>1000)
        {
            Destroy(myTransform.gameObject);// destory unnecassary platforms
        }
    }
    /// <summary>
    /// Creates a New Vector3 
    /// SPawns a prefab with the new Vector 
    /// Switches between (reverse == true) && (reverse == false)
    /// flips the sprite on the x axis if reverse == true;
    /// tells the new parts where there have neighbours
    /// partens the new backgrounds 
    /// </summary>
    /// <param name="rightOrLeft"></param>
    public void SpawnPart(int rightOrLeft)
    {
        Vector3 newPosition = new Vector3(myTransform.position.x + myTransform.localScale.x * partWidth * rightOrLeft, myTransform.position.y, myTransform.position.z);
        //calc the new position for the new backgound and flips them dempening in rightOrLeft 

        //Debug.Log(myTransform.position.x);
        //Debug.Log(myTransform.localScale.x);
        //Debug.Log(partWidth);

        GameObject newPart = Instantiate(partPrefab, newPosition, partPrefab.transform.rotation, transform.parent);
        //creates a new GameObject with new the postition and the old rotation and parents it to its container
        Tiling newPartTiling = newPart.GetComponent<Tiling>();
        newPartTiling.reverse = !reverse;// swap between true/false
        // flipX has the same bool value as reverse
        newPart.GetComponent<SpriteRenderer>().flipX = newPartTiling.reverse;

        if (rightOrLeft == -1)
        {
            newPartTiling.rightPart = true;
        }
        else if (rightOrLeft == 1)
        {
            newPartTiling.leftPart = true;
        }
    }
}