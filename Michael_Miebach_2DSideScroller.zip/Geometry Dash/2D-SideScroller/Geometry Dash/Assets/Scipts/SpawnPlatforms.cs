﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPlatforms : MonoBehaviour {

    public GameObject platformPrefab;  // drag in the Prefab in the Inspector
    public float spawnDistanzX= 100;
    public float spawnDistanzY=20;
    private static Vector3 lastPlatPos; // y start value for the next platform
    public Vector3 _lastPlatPos
    {
        get
        {
            return lastPlatPos;
        }
    }
    
    private GameObject player;          //player ref
    private Transform parentTrans;      //ref to the Parentobject(PlatformContainer)

    private System.Random sysRan;       // random value for prozedural Levelgenerating
    public int seed = 33;               //  seed value for the random-algorhythem
                                        // if u put in the same seed it will "randomly" generate the same level

    private void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        parentTrans = GameObject.FindGameObjectWithTag("Platformcontainer").transform;
    }
    
    private void Start()
    {
        sysRan = new System.Random(seed);  // var sysRan = random values based on (33)
        CreatePlatform(platformPrefab.transform.position); //first platform so the new once have a lastPlatPos
        for (int i = 0; i < 20; i++)
        {
            CreatePlatform(new Vector3(lastPlatPos.x + (spawnDistanzX / 4), lastPlatPos.y, player.transform.position.z)); //start Platforms
        }
    }

    /// <summary>
    ///  constuctor for platforms
    ///  newPlatformPos  as the  y value 
    ///  newPlatformPos as the new lastPlatPos
    /// </summary>
    /// <param name="newPlatformPos"></param>
    public void CreatePlatform(Vector3 newPlatformPos)
    {
       GameObject platform = Instantiate(platformPrefab, newPlatformPos, Quaternion.identity,parentTrans).gameObject;
        lastPlatPos = newPlatformPos;// basic y postion for the next platform
    }
    /// <summary>
    /// acctaully spawns the platform
    /// y value = lastPlatpos (+, -, or nothing)
    /// spawns above, below or on the same higth depending on the swizchstatment result
    /// </summary>
    public  void SpawnPlatform()
    { 
        int randomValue = sysRan.Next(5); // creates random values based on seed with the max hight of 5 (Results: 0,1,2,3,4)
                                           // uses the next value from randomValue.(seed)

        switch (randomValue)
        {
            case 0:
               // creates the next platform above the last one
                CreatePlatform(new Vector3(lastPlatPos.x + spawnDistanzX, lastPlatPos.y + spawnDistanzY, player.transform.position.z));
                break;
            case 1:
                // creates the next platform below the last one
                if (lastPlatPos.y - spawnDistanzY < -5)
                {
                    lastPlatPos.y = 0;
                }
                CreatePlatform(new Vector3(lastPlatPos.x + (spawnDistanzX), lastPlatPos.y - spawnDistanzY, player.transform.position.z));
                break;
            case 2:
                // creates the next platform on the same hight as the last one
                CreatePlatform(new Vector3(lastPlatPos.x + spawnDistanzX, lastPlatPos.y, player.transform.position.z));
                break;
            case 3:
                //spawns the next platform with a shorter distanz
                if (lastPlatPos.y - spawnDistanzY < -5) // if the last platform is to low, we need to spawn it higher instead
                {
                    CreatePlatform(new Vector3(lastPlatPos.x + spawnDistanzX, lastPlatPos.y + spawnDistanzY, player.transform.position.z));
                    return;
                }
                    //spawn with a short distanz
                CreatePlatform(new Vector3(lastPlatPos.x + (spawnDistanzX/2), lastPlatPos.y-spawnDistanzY, player.transform.position.z));
                break;
            case 4:
                // creates a row of platforms on the same hight as the last one
                for (int i = 0; i < 2; i++)
                {
                CreatePlatform(new Vector3(lastPlatPos.x + (spawnDistanzX/4), lastPlatPos.y, player.transform.position.z));
                }
                break;
        }
    }
}
