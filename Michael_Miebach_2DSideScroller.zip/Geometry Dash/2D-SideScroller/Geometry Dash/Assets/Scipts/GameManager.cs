﻿using UnityEngine.SceneManagement;
using UnityEngine.UI;
using UnityEngine;

public class GameManager : MonoBehaviour {

    private Transform player;
    private SpawnPlatforms spawnPlatforms; // spawnsPlatform Script
    private Camera cam;
    public RawImage blackFadeIn; // black image to fade in the game
    public RawImage blackFadeOut; // black image to fade out the game
    public Text endScore; // Score when the player died
    public int dieDuration=3;// how long the game should wait until loading the scene

    private void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform; // player ref
        spawnPlatforms = GetComponent<SpawnPlatforms>();    // spawnPlatforms Scrit ref
        cam = player.GetComponentInChildren<Camera>();   // main camera ref
    }
    private void Start()
    {

        blackFadeIn.CrossFadeAlpha(0, dieDuration, false); // fade in the game right when it starts
      

    }
    private void FixedUpdate()
    {
        if (Vector3.Distance(player.position, spawnPlatforms._lastPlatPos)<1000) // distanz between player and the last platform spawned
        {
            spawnPlatforms.SpawnPlatform();
        }

        if (player.position.y < -0) // fallen down from the platforms
        {
            blackFadeOut.CrossFadeAlpha(255, dieDuration,false); // fade Out the game
            endScore.CrossFadeAlpha(255, dieDuration, false); // fade Out the game

            cam.orthographicSize--; // zoom in the camera
            Invoke("LoadCurrentScene", dieDuration); //load current scene after 3 sec
        }
    }
    /// <summary>
    /// only used for invoke
    /// </summary>
       private void LoadCurrentScene()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
}
