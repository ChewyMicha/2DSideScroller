﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Parallaxing : MonoBehaviour {

    public Transform[] backgrounds; // Array for all the backgrounds
    private float[] parallaxScale;  // parallaxScale for each Background
    public float smooth = 3;        // parallaxing amount(the same multiplyer for all backgrounds)
    private Transform cam;          // referenz to the main Camera
    private Vector3 previousCamPos; // position of the camera in the last frame

    private void Awake()
    {
        cam = Camera.main.transform; //camera ref
    }
    private void Start()
    {
        previousCamPos = cam.position;
        parallaxScale = new float[backgrounds.Length]; //creating an array for parallaxScales with the same length as backgorunds
        for (int i = 0; i < backgrounds.Length; i++)   // for all Backgrounds
        {
            parallaxScale[i] = backgrounds[i].position.z * -1;  // scale = Backgrounds.z position
        }
    }
    private void Update()
    {
        for (int i = 0; i < backgrounds.Length; i++)
        {
            float parallaxAmount = (previousCamPos.x - cam.position.x) * parallaxScale[i]; 
            //calc distanz between last cam position and current cam Position mulitplayed with parallaxScale(position.z value of each background)
            float backgroundTargetPosX = backgrounds[i].position.x + parallaxAmount;
            //calc ther new x pos of the background
            Vector3 newBackgroundPos = new Vector3(backgroundTargetPosX, backgrounds[i].position.y, backgrounds[i].position.z);
            // creat a Vector 3 with the new x postion
            backgrounds[i].position = Vector3.Lerp(backgrounds[i].position, newBackgroundPos, smooth * Time.deltaTime); 
            // fade between old  position and new position
        }
        previousCamPos = cam.position; //set the new "old cam positon"
    }
}
