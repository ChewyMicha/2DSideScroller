﻿using UnityEngine.UI;
using UnityEngine;

public class Score : MonoBehaviour {

    private int score;
    public Text scoreText;
    private Transform player;

    private void Awake()
    {
        InvokeRepeating("ScorePlus", 0, .5f);  //every 0.5seconds
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }


    private void FixedUpdate()
    {
        if (player.position.y > -0) // fallen down from the platforms
        {
        scoreText.text = "Score: " + score.ToString() ;

        }
    }

    /// <summary>
    /// only to use InvokeRepeating
    /// </summary>
    private void ScorePlus()
    {
        score++;
    }
}
